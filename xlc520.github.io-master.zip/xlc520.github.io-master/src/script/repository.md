---
author: xlc520
title: 京东脚本仓库
description: 京东脚本仓库
date: 2022-01-03
category: Script
tag: Script
article: true
dateline: true
icon: type
password: 
---
# 京东脚本仓库

2022年2月8日
https://github.com/danteswx/fxxk

https://github.com/woaim65/Oz

https://github.com/xdhgsq/xdh

https://github.com/whzsyx/xuescripts

https://github.com/sanbing666/scripts

https://github.com/XCould/jd-scripts-docker

https://github.com/skyyaman/temp

https://github.com/linmudaye/linmudaye



```shell

chiupam仓库(京喜工厂瓜分电力开团ID) ql repo https://github.com/chiupam/JD_Diy.git "activeId" 1 1-23/4 * * *
柠檬（胖虎）仓库  ql repo https://github.com/panghu999/panghu.git "jd_"  3 1-23/4 * * *

Ariszy（Zhiyi-N）仓库  ql repo https://github.com/Ariszy/Private-Script.git "JD"  5 1-23/4 * * *

jiulan仓库  ql repo https://github.com/jiulan/platypus.git "jd_|jx_" "" "overdue" "main" 7 1-23/4 * * *

passerby-b仓库  ql repo https://github.com/passerby-b/JDDJ.git "jddj_" "_cookie|_getck" "^jd[^_]"  9 1-23/4 * * *

curtinlv仓库  ql repo https://github.com/curtinlv/JD-Script.git "jd_"  13 1-23/4 * * *

cdle仓库  ql repo https://github.com/cdle/xdd.git "jd_" "disposable|expired|jdc"  15 1-23/4 * * *

smiek2221(青蛙)仓库  ql repo https://github.com/smiek2221/scripts.git "jd_|gua_" "" "^MovementFaker|^JDJRValidator|^ZooFaker|^sign" 17 1-23/4 * * *

star261仓库 ql repo https://github.com/star261/jd.git "jd_|star_" "" "code" "main" 19 1-23/4 * * *

温某人仓库  ql repo https://github.com/Wenmoux/scripts.git "other|jd" "" "" "wen" 21 1-23/4 * * *

he1pu仓库  ql repo https://github.com/he1pu/JDHelp.git "jd_|jx_|getJDCookie" "Coupon|update" "^jd[^_]|USER|^sign|^ZooFaker|utils" 23 1-23/4 * * *

shufflewzc仓库 ql repo https://github.com/shufflewzc/faker2.git "jd_|jx_|gua_|jddj_|getJDCookie" "activity|backUp|Coupon|update" "^jd[^_]|USER|^JS|^TS|^JDJRValidator_Pure|^ZooFaker|^sign" 25 1-23/4 * * *

JDHelloWorld仓库 ql repo https://github.com/JDHelloWorld/jd_scripts.git "jd_|jx_|getJDCookie" "activity|backUp|Coupon|enen|update|test" "^jd[^_]|USER|^TS|utils|notify|env|package|ken.js" 27 1-23/4 * * *

NobyDa仓库(拉取京东签到基础脚本JD_DailyBonus.js专用) ql repo https://github.com/NobyDa/Script.git "JD-DailyBonus" "" "JD_DailyBonus" "master" 29 1-23/4 * * *

Tsukasa007仓库 ql repo https://github.com/Tsukasa007/my_script.git "jd_|jx_" "jdCookie|USER_AGENTS|sendNotify|backup" "" "master" 31 1-23/4 * * *

Aaron-lv仓库 ql repo https://github.com/Aaron-lv/sync.git "jd_|jx_|getJDCookie" "activity|backUp|Coupon" "^jd[^_]|USER|utils" "jd_scripts" 33 1-23/4 * * *





【Faker集合仓库】
 ql repo https://ghproxy.com/https://github.com/shufflewzc/faker2.git "jd_|jx_|gua_|jddj_|getJDCookie" "activity|backUp" "^jd[^_]|USER|ZooFaker_Necklace.js|JDJRValidator_Pure|sign_graphics_validate"

 【curtinlv仓库】
ql repo https://github.com/curtinlv/JD-Script.git

【温某某】
ql repo https://ghproxy.com/https://github.com/shufflewzc/Wenmoux.git 
 
【柠檬（胖虎）】
ql repo https://github.com/panghu999/panghu.git "jd_"

```