---
author: xlc520
title: 浏览器UA
description: 浏览器UA
date: 2022-02-11
category: other
tag: other
article: true
timeline: true
icon: type
password: 
---
# 浏览器UA


更新：2022年6月6日11:18:17

```
Mozilla/5.0 (Linux; Android 11; Redmi K30 5G Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Mobile Safari/537.36 baiduboxapp/3.2.5.10 SearchCraft/3.9.1 (Baidu; P1 11) Quark/3.8.4.128
```
```
Mozilla/5.0 (Linux; Android 11; Redmi K30 5G Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Mobile Safari/537.36 baiduboxapp/3.2.5.10 SearchCraft/3.9.1 (Baidu; P1 11) Quark/3.8.4.128 UCBrowser/12.0.4.985 MQQBrowser/7.2.1.2965 XiaoMi/MiuiBrowser/11.9.2 ALiSearchApp/2.4 AliApp(TB/9.5.6) BingWeb/6.9.6 3gpp-gba
```
```
Mozilla/5.0 (iPhone; CPU iPhone OS 11_4_1 like Mac OS X) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/95.0.4638.69 Mobile Safari/537.36 Quark/3.8.4.128 UCBrowser/12.0.4.985 baiduboxapp/3.2.5.10 MQQBrowser/7.2.1.2965 XiaoMi/MiuiBrowser/11.9.2 SearchCraft/2.0.0 ALiSearchApp/2.4 AliApp(TB/9.5.6) BingWeb/6.9.6 3gpp-gba
```





百度+简单搜索+苹果+微信+夸克+QQ浏览器+Uc浏览器+微博,(带自动翻页)----（自用）

> 有`MicroMessenger/8.0.16.2640(0x28001037) `有会导致CSDN打开跳微信登陆

更新：2022年4月14日09:11:07
百度+简单搜索+csdn+zhihu
```
Mozilla/5.0 (Linux; Android 11; zh-cn; Redmi K30 5G Build/RKQ1.200826.002; wv lite baiduboxapp) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/98.0.4758.80 Mobile Safari/537.36 SearchCraft/3.9.2 T7/13.3 SP-engine/2.41.0 baiduboxapp/ (Baidu; P1 11) CSDNApp/5.3.0(Android)wToken/0.0.1 com.zhihu.android/Futureve/8.14.0
```

Mozilla/5.0 (Linux; Android 11; zh-cn; Redmi K30 5G Build/RKQ1.200826.002; wv lite baiduboxapp) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/98.0.4758.80 Mobile Safari/537.36 SearchCraft/3.9.2 T7/13.3 SP-engine/2.41.0 baiduboxapp/ (Baidu; P1 11) MQQBrowser/26 Quark/4.5.5.155 UCBrowser/13.0.0.1080 Redmi K30 5G_11_weibo_12.2.1_android MMWEBID/999 Process/toolsmp WeChat/arm64 Weixin NetType/WIFI Language/zh_CN ABI/arm64

苹果+百度+简单搜索+夸克+微信，（带自动翻页）

Mozilla/5.0 (Linux; Android 12.0.1; zh-cn; Pixel 6 Pro; wv lite baiduboxapp) baiduboxapp/ AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/98.0.4758.46 Mobile Safari/537.36 SearchCraft/3.7.0 (Baidu; P1 9) Quark/4.5.5.155 MMWEBID/4268 MicroMessenger/8.0.16.2640(0x28001037) Process/toolsmp WeChat/arm64 Weixin NetType/WIFI Language/zh_CN ABI/arm64



百度App

Mozilla/5.0 (Linux; Android 11; Redmi K30 5G Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/76.0.3809.89 Mobile Safari/537.36 T7/13.3 SP-engine/2.41.0 baiduboxapp/13.3.0.11 (Baidu; P1 11) NABar/1.0

Mozilla/5.0 (Linux; Android 11; Redmi K30 5G Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/76.0.3809.89 Mobile Safari/537.36 T7/13.3 light/1.0 SP-engine/2.41.0 baiduboxapp/13.3.0.11 (Baidu; P1 11)

Mozilla/5.0 (Linux; Android 11; Redmi k40 Build/QKQ1.191222.002) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.203 mobile Safari/537.36baiduboxapp/3.2.5.10 SearchCraft/2.8.2 (Baidu; P1 10)

QQ浏览器
Mozilla/5.0 (Linux; U; Android 11; zh-cn; Redmi K40 Pro Build/QKQ1.200114.002) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/77.0.3865.120 MQQBrowser/11.0 Mobile Safari/537.36 COVC/045429

Uc浏览器
Mozilla/5.0 (Linux; U; Android 11; zh-CN; Redmi K40 Pro Build/QKQ1.190825.002) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/57.0.2987.108 UCBrowser/13.0.0.1080 Mobile Safari/537.36

Quark浏览器+简单搜索
Mozilla/5.0 (Linux; Android 11; Redmi K40 Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/84.0.4147.105 Mobile Safari/537.36 SearchCraft/2.8.2 baiduboxapp/3.2.5.10

QQ
Mozilla/5.0 (Linux; U; Android 11; zh-cn; Redmi K40 Pro Build/PKQ1.181121.001) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/66.0.3359.126 MQQBrowser/9.4 Mobile Safari/537.36

微信

Mozilla/5.0 (Linux; Android 11; Redmi K30 5G Build/RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/86.0.4240.99 XWEB/3185 MMWEBSDK/20211001 Mobile Safari/537.36 MMWEBID/999 MicroMessenger/8.0.16.2040(0x2800105F) Process/toolsmp WeChat/arm64 Weixin NetType/WIFI Language/zh_CN ABI/arm64

Mozilla/5.0 (Linux; Android 11; Redmi K40 Pro Build/QKQ1.190910.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.62 XWEB/2757 MMWEBSDK/201101 Mobile Safari/537.36 MMWEBID/70 MicroMessenger/7.0.21.1800(0x2700153B) Process/toolsmp WeChat/arm64 Weixin NetType/4G Language/zh_CN ABI/arm64

Iphone
Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1