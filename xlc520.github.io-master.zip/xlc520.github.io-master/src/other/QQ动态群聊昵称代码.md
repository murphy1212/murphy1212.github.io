---
author: xlc520
title: QQ动态群聊昵称代码
description: 
date: 2022-06-02
category: other
tag: 
 - other
 - QQ
article: true
timeline: true
icon: others
password: 
---

# QQ动态群聊昵称代码

## 代码

- 会变色钻石 `<$ǿĀD>钻石<$ǿĀD>` 效果图：

![img](http://122.9.159.116:5244/d/ecloud180/images/blogImage/1620-16536500405884.png)

钻石

- 手掌比心 `<$ÿĀ">比心<$ÿĀ">` 效果图：

![img](http://122.9.159.116:5244/d/ecloud180/images/blogImage/1620-16536500405881.png)

比心

- 滑稽 `<$²>滑稽<$²>` 效果图：

![img](http://122.9.159.116:5244/d/ecloud180/images/blogImage/1620-16536500405882.png)

滑稽

- 可爱的手掌 `<$ÿĀ>小手<$ÿĀ>` 效果图：

![img](http://122.9.159.116:5244/d/ecloud180/images/blogImage/1620-16536500405883.png)

会动的小手

## 注意

用代码改完群聊名称后不会立即显示，可以重新进去一次群资料即可刷新出来。