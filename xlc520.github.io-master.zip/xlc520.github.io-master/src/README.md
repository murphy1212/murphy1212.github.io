---
home: true
layout: Blog
icon: home
title: 博客主页
# heroImage: /logo.svg
heroText: StudyNote - 个人学习笔记
heroFullScreen: true
bgImage: https://api.btstu.cn/sjbz/api.php?lx=fengjing&format=images
tagline: 昨夜西风凋碧树，独上高楼，望尽天涯路。<br><br>衣带渐宽终不悔，为伊消得人憔悴。<br><br>众里寻他千百度，蓦然回首，那人却在，灯火阑珊处。
projects:
  - icon: project
    name: 学习
    desc: 学习笔记
    link: /study/

  - icon: link
    name: IDEA
    desc: IDEA学习
    link: /idea/

  - icon: book
    name: Linux
    desc: Linux学习
    link: /linux/

  - icon: article
    name: 脚本
    desc: 各种脚本
    link: /script/

  # - icon: friend
  #   name: 伙伴名称
  #   desc: 伙伴详细介绍
  #   link: https://你的伙伴链接

  # - icon: /logo.svg
  #   name: 自定义项目
  #   desc: 自定义详细介绍
  #   link: https://你的自定义链接

footer: 两情若是久长时，又岂在朝朝暮暮
