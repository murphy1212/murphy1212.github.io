---
author: xlc520
title: Lenovo联想
description: Lenovo联想
date: 2022-01-10
category: Tools
tag: Tools
article: true
dateline: true
icon: type
password: 
---
# Lenovo

## 联想工程师204个内部专用工具

[http://u7.1.xainjo.com/pc/lxzyxgj.zip](http://u7.1.xainjo.com/pc/lxzyxgj.zip)