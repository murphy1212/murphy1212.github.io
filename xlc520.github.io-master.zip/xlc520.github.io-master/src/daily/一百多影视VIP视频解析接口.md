---
author: xlc520
title: 一百多影视VIP视频解析接口
description: 一百多影视VIP视频解析接口
date: 2022-03-27
category: daily
tag: daily
article: true
timeline: true
icon: type
password: 
---

# 一百多影视VIP视频解析接口

一百多影视VIP视频解析接口，接口支持解析优酷、爱奇艺、腾讯、芒果、乐视、搜狐、MP4、M3U8、FLV等等，
需要自测，有可能有失效的

https://2.08bk.com/?url=

https://www.8090g.cn/jiexi/?url=

https://www.administratorw.com/admin.php?url=

https://660e.com/?url=

https://www.pangujiexi.com/pangu/?url=

https://jiexi8.com/vip/index.php?url=

https://api.bingdou.net/?url=

https://jx.idc126.net/jx/?url=

https://jqaaa.com/jx.php?url=

https://www.xymav.com/?url=

http://api.bbbbbb.me/jx/?url=

http://api.bbbbbb.me/yunjx/?url=

http://api.bbbbbb.me/vip/?url=

http://api.bbbbbb.me/yun/?url=

http://api.baiyug.vip/index.php?url=

http://vip.jlsprh.com/?url=

http://jx.598110.com/?url=

http://jx.598110.com/index.php?url=

http://vip.jlsprh.com/index.php?url=

http://api.nobij.top/jx/?url=

https://jx.618g.com/?url=

http://tv.wandhi.com/go.html?url=

https://www.1717yun.com/jx/ty.php?url=

https://cdn.yangju.vip/k/?url=

https://api.sigujx.com/?url=

https://vip.jaoyun.com/index.php?url=

https://api.bbbbbb.me/jx/?url=

https://vip.mpos.ren/v/?url=

https://jx.598110.com/index.php?url=

https://www.kpezp.cn/jlexi.php?url=

https://api.927jx.com/vip/?url=

https://api.tv920.com/vip/?url=

https://api.lhh.la/vip/?url=

https://api.8bjx.cn/?url=

https://mcncn.cn/?url=

https://jx.f41.cc/?url=

https://www.ckmov.vip/api.php?url=

https://www.33tn.cn/?url=

https://jx.1ff1.cn/?url=

https://py.ha12.xyz/sos/index.php?url=

http://www.82190555.com/index/qqvod.php?url=

http://www.wmxz.wang/video.php?url=

https://www.1717yun.com/jiexi/?url=

http://jqaaa.com/jx.php?url=

http://api.lequgirl.com/?url=

http://api.xiuyao.me/jx/?url=

https://beaacc.com/api.php?url=

https://www.kkflv.com/?url=

http://jx.598110.com/zuida.php?url=

http://jx.598110.com/duo/index.php?url=

http://api.bbbbbb.me/jiexi/?url=

https://www.administratorw.com/video.php?url=

http://beaacc.com/api.php?url=

https://jx.lache.me/cc/?url=

https://www.pangujiexi.cc/jiexi.php?url=

https://vip.qi71.cn/?url=

https://www.nxflv.com/?url=

https://jx.618ge.com/jx/5.php?url=

https://vip.jlsprh.com/?url=

https://api.flvsp.com/?url=

https://www.administrator5.com/admin.php?url=

http://vip.26db.cn/b/?url=

http://vip.26db.cn/c/?url=

http://vip.26db.cn/g/?url=

http://vip.26db.cn/f/?url=

http://vip.26db.cn/a/?url=

http://jx.idc126.net/jx/?url=

http://v.yhgou.cc/2019/?url=

http://okjx.cc/?url=

https://api.sigujx.com/jx/?url=

http://api.nobij.top/?url=

https://www.jiexila.com/?url=

https://jx.fuxing56.com/jiexi/?url=

https://jx.youyitv.com/?url=

https://www.qianyicp.com/jiexi/index.php?url=

http://vip.tuidu.com/play/?url=

http://www.333zx.cn/0jiexi/8090/?url=

https://www.qianyicp.com/jiexi/?url=

https://yun.nxflv.com/?url=

http://j.zz22x.com/jx/?url=

https://api.3jx.top/vip/?url=

https://jiexi.380k.com/?url=

http://jqaaa.com/jq3/?url=

http://dhyjiexi.arpps.com/?url=

http://s1y2.com/?url=

https://www.cuan.la/?url=

https://jqaaa.com/jq3/?url=&url=

http://jx.xdiaosi.com/?url=

http://www.4080jx.cc/jx/?url=

https://jx.70808.net/?url=

http://jx.rdhk.net/?url=

https://api.xdiaosi.com/?url=

http://jqaaa.com/jq3/?url=&url=

http://jx.52a.ink/?url=

http://www.1717yun.com/jx/ty.php?url=

http://api.taovb.com/?url=

https://api.927jx.com/vip/jx.php?url=

http://cdn.yangju.vip/k/?url=

http://www.sfsft.com/admin.php?url=

https://api.jiexi.la/?url=

https://atyys.com/jx.php?id=0&url=

http://jx.x-99.cn/m3u8.php?url=

http://api.3jx.top/vip/?url=

http://www.82190555.com/video.php?url=

http://api.drgxj.com/jiexi/?url=

https://api.daidaitv.com/index/?url=

https://www.h8jx.com/jiexi.php?url=

https://api.653520.top/vip/?url=

https://www.8090g.cn/beiyong/?url=

http://jx.4080jx.cc/?url=

http://vip.baores.com/?url=

http://www.47jx.com/?url=

https://vip.66parse.club/?url=

https://www.8090g.cn/ceshi/?url=

https://api.52jiexi.top/?url=

https://jx5.178du.com//p1//?url=

https://jx.178du.com/jx2.php?url=

https://jx.kingtail.xyz/?url=

https://api.78sy.cn/?url=

https://okjx.cc/?url=

https://jx.ivito.cn/?url=

http://www.333zx.cn/0jiexi/nuoxun/?url=

https://5.5252e.com/jx.php?url=

http://api.bbbbbb.me/playm3u8/?url=

https://okjx.cc/?url=

https://vip.parwix.com:4433/player/?url=

https://jx.m3u8.tv/jiexi/?url=

https://m2090.com/?url=

http://17kyun.com/api.php?url=

https://api.v6.chat/?url=

https://v.7cyd.com/vip/?url=

https://5.nmgbq.com/jq1/?url=