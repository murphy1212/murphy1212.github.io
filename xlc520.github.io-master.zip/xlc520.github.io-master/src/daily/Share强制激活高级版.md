---
author: xlc520
title: Share强制激活高级版
description: 
date: 2022-08-22
category: daily
tag: daily
article: true
timeline: true
icon: date
password: 
---

# Share强制激活高级版

​              

由于Share停更，高级版也无法激活了，所以这里给出强制激活的方法[来自酷安用户屈指西风几时来]

下面是效果图

![img](http://122.9.159.116:5244/d/ecloud180/images/blogImage//Screenshot_20220501_120140_com.hengye.share.jpg)



## 下载原版Share及小黄鸟抓包软件

https://tidecherish.lanzout.com/b01jf9w1i

提取码:`Meow`

## 打开Share进入高级版激活码界面

![img](http://122.9.159.116:5244/d/ecloud180/images/blogImage//Screenshot_20220501_120738_com.hengye.share.jpg)

## 输入1111111-2222-3333-4444-555555555555之后不要点确定

## 打开小黄鸟，安装证书之后目标选择Share

![img](http://122.9.159.116:5244/d/ecloud180/images/blogImage//Screenshot_20220501_121008_com.guoshi.httpcanary.premium_edit_104977836891272.jpg)

## 点击软件主页右下角小飞机，变成绿色后开始抓包

![img](http://122.9.159.116:5244/d/ecloud180/images/blogImage//Screenshot_20220501_121123_com.guoshi.httpcanary.premium_edit_104993550089707.jpg)

## 切换到Share，点击确定

![img](http://122.9.159.116:5244/d/ecloud180/images/blogImage//Screenshot_20220501_121353_com.hengye.share.jpg)

## 弹出弹窗的同时小黄鸟提示抓包成功，返回小黄鸟

找到api.yehengye.com开头的抓包记录，修改响应为

{"code":0,"data":{"code":"喵柒破解","activated":true,"orderld":"","activeC

ount":0,"timestamp":

32472115200000,"s_expire":false}}

「喵柒破解」这四个字可以任意替换

具体步骤如下



![img](http://122.9.159.116:5244/d/ecloud180/images/blogImage//result-2022-05-01-12-23-34.png)



## 保存后返回Share重新输入
```
1111111-2222-3333-4444-555555555555
```