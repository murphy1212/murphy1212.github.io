---
author: xlc520
title: 一个减少MIUI动画掉帧的方法
description: 
date: 2022-06-18
category: daily
tag: daily
article: true
timeline: true
icon: date
password: 
---

# 一个减少MIUI动画掉帧的方法

分享一个减少MIUI12动画掉帧的方法。

![图片](http://122.9.159.116:5244/d/ecloud180/images/blogImage/640-16542238760163.jpeg)

![图片](http://122.9.159.116:5244/d/ecloud180/images/blogImage/640-16542238760162.jpeg)

应用管理找到系统跟踪清除数据
然后进入开发者选项中的系统跟踪选择关闭跟踪可调试应用
（没有停用hw叠加层，动画也更流畅了）