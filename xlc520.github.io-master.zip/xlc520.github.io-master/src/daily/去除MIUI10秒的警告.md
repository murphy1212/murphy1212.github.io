---
author: xlc520
title: 去除MIUI10秒的警告
description: 去除MIUI10秒的警告
date: 2022-02-17
category: daily
tag: daily
article: true
timeline: true
icon: type
password: 

---

# 去除MIUI10秒的警告

打开Thanox，找到手机管家，选择活动管理，搜索这个活动
com.miui.permcenter.privacymanager.SpecialPermissionInterceptActivity
把这个活动禁用，立即生效
以后无障碍/安装未知应用/勿扰等都不会弹出警告了

![img](http://image.coolapk.com/feed/2022/0108/07/2064506_f18ce68b_8655_7643_90@324x720.gif)

![img](http://image.coolapk.com/feed/2022/0108/07/2064506_223ddc9c_8655_7651_953@1080x2400.jpeg.m.jpg)