---
author: xlc520
title: 表单系统
description: 表单系统
date: 2022-01-01
category: Study
tag: Study
article: true
dateline: true
icon: type
password: 
---
# 表单系统

> 包括了前端 和 后端

Variant Form

🚀一款高效的Vue 2低代码表单，可视化设计，一键生成源码

[https://www.vform666.com/](https://www.vform666.com/)



Element UI表单设计及代码生成器

[jakhuang.github.io/form-generator](jakhuang.github.io/form-generator)

[https://github.com/JakHuang/form-generator](https://github.com/JakHuang/form-generator)

[https://gitee.com/mrhj/form-generator](https://gitee.com/mrhj/form-generator)



工作流，表单，报表结合的多模块系统

[www.plumdo.com/plumdo-work/#/design](www.plumdo.com/plumdo-work/#/design)

[https://github.com/wengwh/plumdo-work](https://github.com/wengwh/plumdo-work)

[https://gitee.com/wengwh/plumdo-work](https://gitee.com/wengwh/plumdo-work)



Tduck-填鸭收集器是一款开源的表单在线收集系统，后台基于SpringBoot+MybatisPlus+MySql+Redis，前端基于Vue ElementUI开发，功能强大，界面美观。keywords：问卷/表单/信息收集/survey questionnaire

[www.tduckcloud.com/](www.tduckcloud.com/)

[https://github.com/TDuckCloud/tduck-front](https://github.com/TDuckCloud/tduck-front)



Survey System. 最好用的开源问卷调查系统、表单系统。

[www.diaowen.net](www.diaowen.net)

[https://github.com/wkeyuan/DWSurvey](https://github.com/wkeyuan/DWSurvey)



动态表单页面设计--自动生成页面

[vincentzyc.github.io/form-design/](vincentzyc.github.io/form-design/)

[https://github.com/vincentzyc/form-design](https://github.com/vincentzyc/form-design)